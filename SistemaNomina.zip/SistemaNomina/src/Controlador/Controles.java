/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;
import java.sql.*;
import Modelo.Conexiondb;
import Vista.GestionNomina;
import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

public class Controles 
{
    Conexiondb cn =  new Conexiondb();
    Connection Conexdb = cn.conexiondb();
    PreparedStatement PrepSql;
     public boolean Login (String NombreUsusario,String Contrasena)
    {
        boolean Acc = false ;
        try 
        {
            Statement st =  Conexdb.createStatement();
            ResultSet result =  st.executeQuery("SELECT * FROM AdminRH Where NombreUsuario = '"+NombreUsusario +"' AND Id_Admin = '"+Contrasena+"';");
            if(result.next()== true)
            {
                JOptionPane.showMessageDialog(null,"Bienvenido: "+result.getString(2));
                GestionNomina Gn = new GestionNomina();
                Gn.setVisible(true);
                Gn.UsuarioAdmin = NombreUsusario;
                Acc=true;
            }
            else{
                JOptionPane.showMessageDialog(null,"Error en las credenciales ");
                Acc=false;
            }
        } 
        catch (Exception e) 
        {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return Acc;
    }
     public boolean Consultar (String NombreUsuario,String Contrasena)
     {
         boolean Desbloquear;
         try {
            Statement st =  Conexdb.createStatement();
            ResultSet result =  st.executeQuery("SELECT * FROM AdminRH Where NombreUsuario = '"+NombreUsuario+"' AND Id_Admin = '"+Contrasena+"';");
            if(result.next()== true)
            {
              Desbloquear = true;
            }
            else{
                JOptionPane.showMessageDialog(null,"Usuario No Registrado");
               Desbloquear = false;
            }
         } 
         catch (Exception e)
         {
             System.out.println("Error");
             Desbloquear=false;
         }
        return Desbloquear;
     }
     public void GenerarTablaPersepcionesDeducciones(String [] Columnas,String TablaDb,DefaultTableModel Modelo,JTable TablaSwing)
     {
         try 
         {
            Modelo = new DefaultTableModel();
            for(int i=0;i<Columnas.length;i++)
            {
                Modelo.addColumn(Columnas[i]);
            }
            TablaSwing.setModel(Modelo);
            String sql = "SELECT * FROM "+ TablaDb +";";
            String[] Rows =  new String[4];
            Statement stsql = Conexdb.createStatement();
            ResultSet result =  stsql.executeQuery(sql);
            while(result.next())
            {
                Rows[0] = String.valueOf(result.getInt(1));
                Rows[1] =result.getString(2);
                Rows[2] = String.valueOf(result.getFloat(3));
                Rows[3]="0";
                Modelo.addRow(Rows);
            }
            TablaSwing.setModel(Modelo);
         } 
         catch (Exception e) 
         {
             System.err.println("Error al Listar Tabla");
         }
     }
     public void GenerarTablaPuestos(String [] Columnas,String TablaDb,DefaultTableModel Modelo,JTable TablaSwing)
     {
         try 
         {
            Modelo = new DefaultTableModel();
            for(int i=0;i<Columnas.length;i++)
            {
                Modelo.addColumn(Columnas[i]);
            }
            TablaSwing.setModel(Modelo);
            String sql = "SELECT * FROM "+ TablaDb +";";
            String[] Rows =  new String[2];
            Statement stsql = Conexdb.createStatement();
            ResultSet result =  stsql.executeQuery(sql);
            while(result.next())
            {
                Rows[0] = result.getString(1);
                Rows[1] =result.getString(2);
               
                Modelo.addRow(Rows);
            }
            TablaSwing.setModel(Modelo);
         } 
         catch (Exception e) 
         {
             JOptionPane.showMessageDialog(null,e);
             System.out.println("Error al Listar Tabla "+e.toString());
             
         }
     }
     public void INSERT_INTO(String stringsql)
     {
         try {
             
             PrepSql= Conexdb.prepareStatement(stringsql);
             PrepSql.executeUpdate();
             JOptionPane.showMessageDialog(null, "Datos Insertados");
         } 
         catch (Exception e) 
         {
         JOptionPane.showMessageDialog(null, "Error" + e.toString());
         System.err.println(e.toString());
         }
     } 
     public void DELETE(String stringsql)
     {
         try {
             
             PrepSql= Conexdb.prepareStatement(stringsql);
             PrepSql.executeUpdate();
             JOptionPane.showMessageDialog(null, "Registro Eliminado");
         } 
         catch (Exception e) 
         {
         JOptionPane.showMessageDialog(null, "Error" + e.toString());
         }
     }
     public void UPDATE(String stringsql)
     {
         try {
             
             PrepSql= Conexdb.prepareStatement(stringsql);
             PrepSql.executeUpdate();
             JOptionPane.showMessageDialog(null, "Datos Actualizados");
         } 
         catch (Exception e) 
         {
         JOptionPane.showMessageDialog(null, "Error" + e.toString());
         }
     }
     public boolean ConsultarEntrada(int No_Empleado,String Fecha)
     {
         boolean Entrada=false;
         try 
         {
           Statement st =  Conexdb.createStatement();
            ResultSet result =  st.executeQuery("SELECT Hora_Entrada FROM Asistencia  Where  No_Empleado="+ No_Empleado +" AND Fecha='"+ Fecha +"';");
           if(result.next()== true)
           {
              Entrada=true;
           }
           else
           {
               Entrada=false;
           }
         } 
         catch (Exception e) 
         {
             System.out.println("Error al Consultar");
         }
         return Entrada;
     }
      public boolean ConsultarRegistroEmpresa(String Clave)
     {
           boolean Entrada=false;
         try 
         {
           Statement st =  Conexdb.createStatement();
            ResultSet result =  st.executeQuery("SELECT * FROM Sucursal WHERE Id_Sucursal='"+ Clave+"';");
           if(result.next()== true)
           {
              Entrada=true;
           }
           else
           {
               Entrada=false;
           }
         } 
         catch (Exception e) 
         {
             System.out.println("Error al Consultar");
         }
         return Entrada;
     }
      public void AsignarDatosEmpresa(JTextField txtClave,JTextField txtRazon,JTextField txtDireccion,JLabel LblImagen,String Ruta)
      {
          try 
          {
           Statement stsql = Conexdb.createStatement();
            ResultSet result =  stsql.executeQuery("SELECT * FROM Sucursal");
            String [] Row =  new String[4];
            if(result.next()==true)
            {
                Row[0]=result.getString(1);
               Row[1]=result.getString(2);
               Row[2]=result.getString(3);
              Row[3]=result.getString(4);
                txtClave.setText( Row[0]);
                txtRazon.setText( Row[1]);
                txtDireccion.setText( Row[2]);
                Ruta = Row[3];   
                AsignarGrafico(Ruta, LblImagen);
            }
            else
            {
                 txtClave.setText("");
                txtRazon.setText("");
                txtDireccion.setText("");
                Ruta = "";   
                System.out.println("Error en la consulta");
            }
          }
          catch (Exception e) 
          {
              System.out.println(e.toString());
          }
          
      }
      public void AsignarGrafico(String Ruta,JLabel LblImagen)
      {
           ImageIcon fot = new ImageIcon(Ruta);
             Icon icono = new ImageIcon(fot.getImage().getScaledInstance(LblImagen.getWidth(), LblImagen.getHeight(), Image.SCALE_DEFAULT));
            LblImagen.setIcon(icono);
      }
      public void ConsultarRutaeImg(JLabel LblImg)
      {
        try 
          {
           Statement stsql = Conexdb.createStatement();
            ResultSet result =  stsql.executeQuery("SELECT RutaImagen FROM Sucursal");
           
            if(result.next()==true)
            {
                String Ruta = result.getString(1);
                LblImg.setText(null);
                AsignarGrafico(Ruta,LblImg);
            }
            else
            {
                System.out.println("Error En la Consulta");
                LblImg.setText("Sistema Nómina");
            }
          }
            catch(Exception e)
           {
              System.out.println(e.toString());
          }   
      }
      public void GenerarTablaEmpleados(String [] Columnas,String TablaDb,DefaultTableModel Modelo,JTable TablaSwing)
     {
         try 
         {
            Modelo = new DefaultTableModel();
            for(int i=0;i<Columnas.length;i++)
            {
                Modelo.addColumn(Columnas[i]);
            }
            TablaSwing.setModel(Modelo);
            String sql = "SELECT * FROM "+ TablaDb +";";
            String[] Rows =  new String[9];
            Statement stsql = Conexdb.createStatement();
            ResultSet result =  stsql.executeQuery(sql);
            while(result.next())
            {
                Rows[0]= String.valueOf(result.getInt(1));
                Rows[1]= result.getString(2);
                Rows[2]=result.getString(3);
                Rows[3]=result.getString(4);
                Rows[4]=result.getString(5);
                Rows[5]=String.valueOf(result.getDate(6));
                Rows[6]=result.getString(7);
                Rows[7]=result.getString(8);
                Rows[8]=String.valueOf(result.getFloat(9));
                Modelo.addRow(Rows);
            }
            TablaSwing.setModel(Modelo);
         } 
         catch (Exception e) 
         {
             System.err.println("Error al Listar Tabla"+e.toString());
         }
     }
      public void GenerarTablaTelefonosEmpleados(String [] Columnas,String TablaDb,DefaultTableModel Modelo,JTable TablaSwing,int No_Empleado)
      {
          try 
         {
            Modelo = new DefaultTableModel();
            for(int i=0;i<Columnas.length;i++)
            {
                Modelo.addColumn(Columnas[i]);
            }
            TablaSwing.setModel(Modelo);
            String sql = "SELECT * FROM "+ TablaDb +" WHERE No_Empleado="+ No_Empleado +" ;";
            String[] Rows =  new String[2];
            Statement stsql = Conexdb.createStatement();
            ResultSet result =  stsql.executeQuery(sql);
            while(result.next())
            {
                Rows[0]= String.valueOf(result.getInt(1));
                Rows[1]= result.getString(2);
                System.out.println( Rows[0]);
                System.out.println( Rows[1]);
                Modelo.addRow(Rows);
            }
            TablaSwing.setModel(Modelo);
         } 
         catch (Exception e) 
         {
             System.err.println("Error al Listar Tabla"+e.toString());
         }
      }
       public void GenerarTablaEmpleadosLike(String [] Columnas,String TablaDb,DefaultTableModel Modelo,JTable TablaSwing,String NombreChange)
     {
         try 
         {
            Modelo = new DefaultTableModel();
            for(int i=0;i<Columnas.length;i++)
            {
                Modelo.addColumn(Columnas[i]);
            }
            TablaSwing.setModel(Modelo);
            String sql = "SELECT * FROM "+ TablaDb +" WHERE Nombre LIKE '%"+NombreChange+"%';";
            String[] Rows =  new String[9];
            Statement stsql = Conexdb.createStatement();
            ResultSet result =  stsql.executeQuery(sql);
            while(result.next())
            {
                Rows[0]= String.valueOf(result.getInt(1));
                Rows[1]= result.getString(2);
                Rows[2]=result.getString(3);
                Rows[3]=result.getString(4);
                Rows[4]=result.getString(5);
                Rows[5]=String.valueOf(result.getDate(6));
                Rows[6]=result.getString(7);
                Rows[7]=result.getString(8);
                Rows[8]=String.valueOf(result.getFloat(9));
                Modelo.addRow(Rows);
            }
            TablaSwing.setModel(Modelo);
         } 
         catch (Exception e) 
         {
             System.err.println("Error al Listar Tabla"+e.toString());
         }
     }
    public void GenerarTablaAfore(String [] Columnas,String TablaDb,DefaultTableModel Modelo,JTable TablaSwing)
     {
        try 
         {
            Modelo = new DefaultTableModel();
            for(int i=0;i<Columnas.length;i++)
            {
                Modelo.addColumn(Columnas[i]);
            }
            TablaSwing.setModel(Modelo);
            String sql = "SELECT * FROM "+ TablaDb +";";
            String[] Rows =  new String[2];
            Statement stsql = Conexdb.createStatement();
            ResultSet result =  stsql.executeQuery(sql);
            while(result.next())
            {
                Rows[0] = String.valueOf(result.getInt(1));
                Rows[1] = String.valueOf(result.getFloat(2));
               
                Modelo.addRow(Rows);
            }
            TablaSwing.setModel(Modelo);
         } 
         catch (Exception e) 
         {
             JOptionPane.showMessageDialog(null,e);
             System.out.println("Error al Listar Tabla "+e.toString());
             
         }
     }  
    public void GenerarTablaAforeLIKE(String [] Columnas,String TablaDb,DefaultTableModel Modelo,JTable TablaSwing,String NoEmpChange)
     {
        try 
         {
            Modelo = new DefaultTableModel();
            for(int i=0;i<Columnas.length;i++)
            {
                Modelo.addColumn(Columnas[i]);
            }
            TablaSwing.setModel(Modelo);
            String sql = "SELECT * FROM "+ TablaDb +" WHERE No_Empleado LIKE '%"+NoEmpChange+"%';";
            String[] Rows =  new String[2];
            Statement stsql = Conexdb.createStatement();
            ResultSet result =  stsql.executeQuery(sql);
            while(result.next())
            {
                Rows[0] = String.valueOf(result.getInt(1));
                Rows[1] = String.valueOf(result.getFloat(2));
               
                Modelo.addRow(Rows);
            }
            TablaSwing.setModel(Modelo);
         } 
         catch (Exception e) 
         {
             JOptionPane.showMessageDialog(null,e);
             System.out.println("Error al Listar Tabla "+e.toString());
             
         }
     }
    public void ConsultarAdmin (JTextField txtUsuario,JTextField txtContrasena)
     {
        
         try {
            Statement st =  Conexdb.createStatement();
            ResultSet result =  st.executeQuery("SELECT * FROM AdminRH Where NombreUsuario = '"+txtUsuario.getText()+"';");
            if(result.next()== true)
            {
            txtContrasena.setText(result.getString(1));
             txtUsuario.setText(result.getString(2));
            }
            else{
                JOptionPane.showMessageDialog(null,"Usuario No Registrado");
             
            }
         } 
         catch (Exception e)
         {
             System.out.println("Error"+e.toString());
            
         }
       
     }
    public void GenerarTablaAsistencia(String [] Columnas,String TablaDb,DefaultTableModel Modelo,JTable TablaSwing,String FechaDel,String FechaAl,int NoEmpleado)
     {
        try 
         {
            Modelo = new DefaultTableModel();
            for(int i=0;i<Columnas.length;i++)
            {
                Modelo.addColumn(Columnas[i]);
            }
            TablaSwing.setModel(Modelo);
            String sql = "SELECT * FROM Asistencia WHERE No_Empleado="+NoEmpleado+" AND FECHA BETWEEN '"+FechaDel+"' AND '"+FechaAl+"';";
            String[] Rows =  new String[5];
            Statement stsql = Conexdb.createStatement();
            ResultSet result =  stsql.executeQuery(sql);
            while(result.next())
            {
                Rows[0] = String.valueOf(result.getInt(1));
                 Rows[1] = String.valueOf(result.getInt(2));
                 Rows[2] = result.getString(3);
                 Rows[3] = result.getString(4);
                 Rows[4] = result.getString(5);
               
                Modelo.addRow(Rows);
            }
            TablaSwing.setModel(Modelo);
         } 
         catch (Exception e) 
         {
             JOptionPane.showMessageDialog(null,e);
             System.out.println("Error al Listar Tabla "+e.toString());
             
         }
     } 
     public void AsignarDatosEmpresaNomina(JTextField txtClave,JLabel txtRazon,JTextArea txtDireccion,JLabel LblImagen,String Ruta)
      {
          try 
          {
           Statement stsql = Conexdb.createStatement();
            ResultSet result =  stsql.executeQuery("SELECT * FROM Sucursal");
            String [] Row =  new String[4];
            if(result.next()==true)
            {
                Row[0]=result.getString(1);
               Row[1]=result.getString(2);
               Row[2]=result.getString(3);
              Row[3]=result.getString(4);
                txtClave.setText( Row[0]);
                txtRazon.setText( Row[1]);
                txtDireccion.setText( Row[2]);
                Ruta = Row[3];   
                AsignarGrafico(Ruta, LblImagen);
            }
            else
            {
                 txtClave.setText("");
                txtRazon.setText("");
                txtDireccion.setText("");
                Ruta = "";   
                System.out.println("Error en la consulta");
            }
          }
          catch (Exception e) 
          {
              System.out.println(e.toString());
          }
          
      }
    public void AsignarDatosEmpleado(JTextField lblNo_Empleado,JLabel lblRFC,JLabel lblNombre,JLabel lblIMSS,JLabel lblPuesto,JLabel lblFechaIngreso,JLabel lblSueldoHora,int paramempl)
    {
         try 
          {
           Statement stsql = Conexdb.createStatement();
            ResultSet result =  stsql.executeQuery("SELECT No_Empleado,RFC,Nombre,NoIMSS,Id_Puesto,Fecha_Ingreso,Sueldo_Hora FROM Empleados WHERE No_Empleado="+paramempl+";");
            String [] Row =  new String[7];
            if(result.next()==true)
            {
               lblNo_Empleado.setText(String.valueOf(result.getInt(1)));
               lblRFC.setText(result.getString(2));
                lblNombre.setText(result.getString(3));
                lblIMSS.setText(result.getString(4));
                lblPuesto.setText(result.getString(5));
                lblFechaIngreso.setText(result.getString(6));
                lblSueldoHora.setText(String.valueOf(result.getFloat(7)));
            }
            else
            {
                
                System.out.println("Error en la consulta");
            }
          }
          catch (Exception e) 
          {
              System.out.println(e.toString());
          }
          
    }
    public void GenerarTablaRecibo(String [] Columnas,String TablaDb,DefaultTableModel Modelo,JTable TablaSwing,int No_Empleado)
    {
         try 
         {
            Modelo = new DefaultTableModel();
            for(int i=0;i<Columnas.length;i++)
            {
                Modelo.addColumn(Columnas[i]);
            }
            TablaSwing.setModel(Modelo);
            String sql = "SELECT * FROM "+ TablaDb +" WHERE No_Empleado="+No_Empleado+";";
            String[] Rows =  new String[6];
            Statement stsql = Conexdb.createStatement();
            ResultSet result =  stsql.executeQuery(sql);
            while(result.next())
            {
               Rows[0]=String.valueOf(result.getInt(1));
               Rows[1]="$"+String.valueOf(result.getFloat(2));
               Rows[2]=result.getString(3);
               Rows[3]=String.valueOf(result.getInt(4));
               Rows[4]="$"+String.valueOf(result.getFloat(5));
               Rows[5]="$"+String.valueOf(result.getFloat(6));
                Modelo.addRow(Rows);
            }
            TablaSwing.setModel(Modelo);
         } 
         catch (Exception e) 
         {
             System.err.println("Error al Listar Tabla");
         }
    }
    public void GenerarTablaReciboSinParam(String [] Columnas,String TablaDb,DefaultTableModel Modelo,JTable TablaSwing)
    {
         try 
         {
            Modelo = new DefaultTableModel();
            for(int i=0;i<Columnas.length;i++)
            {
                Modelo.addColumn(Columnas[i]);
            }
            TablaSwing.setModel(Modelo);
            String sql = "SELECT * FROM "+ TablaDb +";";
            String[] Rows =  new String[6];
            Statement stsql = Conexdb.createStatement();
            ResultSet result =  stsql.executeQuery(sql);
            while(result.next())
            {
               Rows[0]=String.valueOf(result.getInt(1));
               Rows[1]="$"+String.valueOf(result.getFloat(2));
               Rows[2]=result.getString(3);
               Rows[3]=String.valueOf(result.getInt(4));
               Rows[4]="$"+String.valueOf(result.getFloat(5));
               Rows[5]="$"+String.valueOf(result.getFloat(6));
                Modelo.addRow(Rows);
            }
            TablaSwing.setModel(Modelo);
         } 
         catch (Exception e) 
         {
             System.err.println("Error al Listar Tabla");
         }
    }
}
