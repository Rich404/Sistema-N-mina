/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.*;
import javax.swing.JOptionPane;
/**
 *
 * @author HpAdmin
 */
public class Conexiondb 
{
    
    Connection conexiondb;
    public Connection conexiondb()
      {
          try
          {
              Class.forName("com.mysql.jdbc.Driver");
           conexiondb=DriverManager.getConnection("jdbc:mysql://localhost/sistemanomina","root","");
          //conexiondb=DriverManager.getConnection("jdbc:mysql://db4free.net:3306/sistemanomina","sistemanomina","sistema0000");
             JOptionPane.showMessageDialog(null,"Exito en la Conexion");
          } catch (Exception e)
          {
            JOptionPane.showMessageDialog(null,"Error en la conexion : "+e.toString());
          }
          
          return conexiondb;
       }   
    
}
